package br.com.nouva.core

class ComonTeste {
    fun string(): String {
        return "Texto aqui"
    }
}